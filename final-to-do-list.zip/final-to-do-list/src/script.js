let currentTask = null;

// =======================
// ELEMENTS
// =======================
const taskInput = document.getElementById("taskInput");
const taskList = document.getElementById("taskList");

const detailsBox = document.getElementById("detailsBox");
const detailsInput = document.getElementById("detailsInput");

const addBtn = document.getElementById("addBtn");
const saveBtn = document.getElementById("saveBtn");
const closeBtn = document.getElementById("closeBtn");

// =======================
// ADD TASK
// =======================
addBtn.addEventListener("click", addTask);

function addTask() {
  const text = taskInput.value.trim();
  if (!text) return;

  const li = document.createElement("li");
  li.textContent = text;

  // store task details
  li.dataset.details = "";

  // OPEN DETAILS
  li.addEventListener("click", () => {
    currentTask = li;

    detailsBox.style.display = "block";
    detailsInput.value = li.dataset.details;
  });

  // DELETE BUTTON
  const del = document.createElement("button");
  del.textContent = "X";
  del.className = "delete-btn";

  del.addEventListener("click", (e) => {
    e.stopPropagation();
    li.remove();

    // hide details if deleting selected task
    if (currentTask === li) {
      detailsBox.style.display = "none";
      currentTask = null;
    }
  });

  li.appendChild(del);
  taskList.appendChild(li);

  taskInput.value = "";
}

// =======================
// SAVE DETAILS
// =======================
saveBtn.addEventListener("click", () => {
  if (currentTask) {
    currentTask.dataset.details = detailsInput.value;
  }

  detailsBox.style.display = "none";
  currentTask = null;
});

// =======================
// CLOSE DETAILS
// =======================
closeBtn.addEventListener("click", () => {
  detailsBox.style.display = "none";
  currentTask = null;
});